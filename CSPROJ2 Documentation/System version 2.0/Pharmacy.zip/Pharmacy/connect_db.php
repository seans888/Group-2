<?php

error_reporting (E_ALL ^ E_NOTICE ^ E_WARNING);
ini_set("display_errors",1);
$con=mysql_connect('localhost','root','') or die("cannot connect to server");
mysql_select_db('pharmacy') or die("cannot connect to database");

?>