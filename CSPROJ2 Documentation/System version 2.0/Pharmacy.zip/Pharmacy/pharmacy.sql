-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2016 at 12:08 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` tinyint(5) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `date`) VALUES
(1, 'admin', 'admin', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `cashier`
--

CREATE TABLE `cashier` (
  `cashier_id` tinyint(5) NOT NULL,
  `first_name` varchar(15) NOT NULL,
  `last_name` varchar(15) NOT NULL,
  `staff_id` varchar(10) NOT NULL,
  `postal_address` varchar(20) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `email` varchar(20) NOT NULL,
  `username` varchar(16) NOT NULL,
  `password` varchar(10) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cashier`
--

INSERT INTO `cashier` (`cashier_id`, `first_name`, `last_name`, `staff_id`, `postal_address`, `phone`, `email`, `username`, `password`, `date`) VALUES
(1, 'Carl Dominique', 'Bueno', '950209', 'Taguig City', '09366993325', 'carl.dominiquebueno@', 'cpbueno', 'cpbueno', '2016-12-10 10:20:43'),
(2, 'Carmelita', 'Buenaflor', '910101', 'Makati City', '09366992140', 'melbuenaflor@gmail.c', 'melbuen', 'melbuen', '2016-12-10 10:21:22');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_id` int(5) NOT NULL,
  `customer_name` varchar(30) NOT NULL,
  `served_by` varchar(15) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Unpaid',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_id`, `customer_name`, `served_by`, `status`, `date`) VALUES
(1, 'Steven Malibay', 'cpbueno', 'Pending', '2016-12-13 13:50:02'),
(2, 'Dianne Biag', 'cpbueno', 'Pending', '2016-12-13 13:52:14'),
(3, 'Angeline Santos', 'cpbueno', 'Pending', '2016-12-13 13:56:08'),
(4, 'Dianne Biag', 'cpbueno', 'Pending', '2016-12-13 14:03:47'),
(5, 'Steven Tamadeo', 'cpbueno', 'Pending', '2016-12-13 14:14:10'),
(6, 'Steven Tamadeo', 'cpbueno', 'Pending', '2016-12-13 14:15:06'),
(7, 'Carl Pascual', 'cpbueno', 'Pending', '2016-12-13 14:15:54'),
(8, 'Jessa Patar', 'cpbueno', 'Pending', '2016-12-13 14:17:10'),
(9, 'Marilou Jojo', 'cpbueno', 'Pending', '2016-12-13 14:18:15'),
(10, 'Imelda Aquino', 'cpbueno', 'Pending', '2016-12-13 14:48:33'),
(11, 'Bongbong Robredo', 'cpbueno', 'Pending', '2016-12-13 14:49:47'),
(12, 'Carl', 'cpbueno', 'Pending', '2016-12-14 01:01:18');

--
-- Triggers `invoice`
--
DELIMITER $$
CREATE TRIGGER `tarehe` AFTER INSERT ON `invoice` FOR EACH ROW BEGIN
     SET @date=NOW();
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_details`
--

CREATE TABLE `invoice_details` (
  `id` tinyint(5) NOT NULL,
  `invoice` int(5) NOT NULL,
  `drug` tinyint(5) NOT NULL,
  `cost` int(5) DEFAULT NULL,
  `quantity` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_details`
--

INSERT INTO `invoice_details` (`id`, `invoice`, `drug`, `cost`, `quantity`) VALUES
(53, 1, 1, 4, 15),
(54, 2, 2, 2, 20),
(55, 2, 5, 6, 15),
(56, 2, 12, 65, 5),
(57, 3, 8, 18, 5),
(58, 3, 2, 2, 30),
(59, 3, 10, 79, 10),
(60, 3, 13, 3, 5),
(61, 3, 14, 6, 5),
(62, 4, 10, 79, 5),
(63, 4, 2, 2, 30),
(65, 4, 13, 3, 3),
(66, 4, 14, 6, 3),
(68, 6, 1, 4, 9),
(69, 6, 11, 99, 5),
(70, 7, 11, 99, 1),
(71, 8, 5, 6, 10),
(72, 9, 12, 65, 5),
(73, 10, 2, 2, 50),
(74, 11, 1, 4, 2),
(75, 11, 2, 2, 2),
(76, 11, 6, 9, 3),
(77, 12, 1, 4, 5),
(78, 12, 15, 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `manager_id` tinyint(5) NOT NULL,
  `first_name` varchar(15) NOT NULL,
  `last_name` varchar(15) NOT NULL,
  `staff_id` varchar(10) NOT NULL,
  `postal_address` varchar(20) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `email` varchar(20) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`manager_id`, `first_name`, `last_name`, `staff_id`, `postal_address`, `phone`, `email`, `username`, `password`, `date`) VALUES
(1, 'Carl Dominique', 'Bueno', '950209', 'Taguig City', '09366993325', 'carl.dominiquebueno@', 'cpbueno', 'cpbueno', '2016-12-10 10:23:59'),
(2, 'Carmelita', 'Buenaflor', '910101', 'Makati City', '09366992140', 'melbuenaflor@gmail.c', 'melbuen', 'melbuen', '2016-12-10 10:24:34');

-- --------------------------------------------------------

--
-- Table structure for table `paymenttypes`
--

CREATE TABLE `paymenttypes` (
  `id` tinyint(5) NOT NULL,
  `Name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paymenttypes`
--

INSERT INTO `paymenttypes` (`id`, `Name`) VALUES
(1, 'Patient'),
(2, 'HMO'),
(3, 'PhilHealth Card'),
(4, 'Cash'),
(5, 'Company');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist`
--

CREATE TABLE `pharmacist` (
  `pharmacist_id` tinyint(5) NOT NULL,
  `first_name` varchar(15) NOT NULL,
  `last_name` varchar(15) NOT NULL,
  `staff_id` varchar(10) NOT NULL,
  `postal_address` varchar(20) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `email` varchar(20) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmacist`
--

INSERT INTO `pharmacist` (`pharmacist_id`, `first_name`, `last_name`, `staff_id`, `postal_address`, `phone`, `email`, `username`, `password`, `date`) VALUES
(1, 'Carl Dominique', 'Bueno', '950209', 'Taguig City', '09366993325', 'carl.dominiquebueno@', 'cpbueno', 'cpbueno', '2016-12-10 10:16:03'),
(3, 'Carmelita', 'Buenaflor', '20161212', 'Taguig City', '09366993325', 'melbuenaflor@gmail.c', 'melbuen', 'qwerty', '2016-12-12 10:33:34'),
(4, 'Glen Roy', 'Rosales', '950209', 'Taguig City', '09366993325', 'glenroyrosales@gmail', 'glenrosale', 'qwerty', '2016-12-14 08:36:31');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `id` tinyint(5) NOT NULL,
  `prescription_id` int(5) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(30) NOT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(6) NOT NULL,
  `postal_address` varchar(20) NOT NULL,
  `invoice_id` tinyint(5) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`id`, `prescription_id`, `customer_id`, `customer_name`, `age`, `sex`, `postal_address`, `invoice_id`, `phone`, `date`) VALUES
(37, 999, 161214, 'Dianne Biag', 21, 'Female', 'Pasay City', 4, '09366992140', '2016-12-13 14:03:47'),
(39, 1000, 161214, 'Steven Tamadeo', 34, 'Male', 'Pasig City', 6, '0932212112', '2016-12-13 14:15:06'),
(40, 1001, 161214, 'Carl Pascual', 26, 'Male', 'Taguig City', 7, '09366993325', '2016-12-13 14:15:54'),
(41, 1002, 161214, 'Jessa Patar', 17, 'Female', 'Pateros', 8, '0909159336', '2016-12-13 14:17:10'),
(42, 1003, 161214, 'Marilou Jojo', 45, 'Female', 'Paranaque City', 9, '0966232345', '2016-12-13 14:18:15'),
(43, 1004, 161214, 'Imelda Aquino', 54, 'Female', 'Quezon City', 10, '0922123891', '2016-12-13 14:48:32'),
(44, 1005, 161214, 'Bongbong Robredo', 47, 'Male', 'Quezon City', 11, '0932212112', '2016-12-13 14:49:46'),
(45, 1006, 161214, 'Carl', 21, 'Male', 'Taguig City', 12, '09366993325', '2016-12-14 01:01:18');

--
-- Triggers `prescription`
--
DELIMITER $$
CREATE TRIGGER `taree` AFTER INSERT ON `prescription` FOR EACH ROW BEGIN
SET@date=NOW();
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `prescription_details`
--

CREATE TABLE `prescription_details` (
  `id` tinyint(5) NOT NULL,
  `pres_id` int(5) NOT NULL,
  `drug_name` tinyint(5) NOT NULL,
  `strength` varchar(15) NOT NULL,
  `dose` varchar(15) NOT NULL,
  `quantity` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription_details`
--

INSERT INTO `prescription_details` (`id`, `pres_id`, `drug_name`, `strength`, `dose`, `quantity`) VALUES
(53, 999, 1, '10mg', '5/day', 15),
(54, 1000, 2, '500mg', '6/day', 20),
(55, 1000, 5, '500mg', '4/day', 15),
(56, 1000, 12, 'N/A', 'N/A', 5),
(57, 1001, 8, 'N/A', 'N/A', 5),
(58, 1001, 2, '500mg', '4/day', 30),
(59, 1001, 10, 'N/A', 'N/A', 10),
(60, 1001, 13, 'N/A', 'N/A', 5),
(61, 1001, 14, 'N/A', 'N/A', 5),
(62, 999, 10, 'n/a', 'n/a', 5),
(63, 999, 2, '500mg', '4/day', 30),
(65, 999, 13, 'n/a', 'n/a', 3),
(66, 999, 14, 'n/a', 'n/a', 3),
(68, 1000, 1, '500mg', '1/day', 9),
(69, 1000, 11, 'n/a', 'n/a', 5),
(70, 1001, 11, 'n/a', 'n/a', 1),
(71, 1002, 5, '500mg', '3/day', 10),
(72, 1003, 12, 'n/a', 'n/a', 5),
(73, 1004, 2, '500mg', '4/day', 50),
(74, 1005, 1, 'n/a', 'n/a', 2),
(75, 1005, 2, '500mg', 'n/a', 2),
(76, 1005, 6, 'n/a', 'n/a', 3),
(77, 1006, 1, 'n/a', 'n/a', 5),
(78, 1006, 15, 'n/a', 'n/a', 5);

-- --------------------------------------------------------

--
-- Table structure for table `receipts`
--

CREATE TABLE `receipts` (
  `reciptNo` int(10) NOT NULL,
  `customer_id` varchar(10) NOT NULL,
  `total` int(10) NOT NULL,
  `payType` varchar(10) NOT NULL,
  `serialno` varchar(10) DEFAULT NULL,
  `served_by` varchar(15) NOT NULL,
  `date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receipts`
--

INSERT INTO `receipts` (`reciptNo`, `customer_id`, `total`, `payType`, `serialno`, `served_by`, `date`) VALUES
(0, '161214', 0, '', '', 'cpbueno', '0000-00-00 00:00:00');

--
-- Triggers `receipts`
--
DELIMITER $$
CREATE TRIGGER `siku` AFTER INSERT ON `receipts` FOR EACH ROW BEGIN
     SET @date=NOW();
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `stock_id` tinyint(5) NOT NULL,
  `drug_name` varchar(45) NOT NULL,
  `category` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  `company` varchar(45) NOT NULL,
  `supplier` varchar(45) NOT NULL,
  `quantity` int(11) NOT NULL,
  `cost` int(11) NOT NULL,
  `status` enum('Available','Inavailable') NOT NULL,
  `date_supplied` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`stock_id`, `drug_name`, `category`, `description`, `company`, `supplier`, `quantity`, `cost`, `status`, `date_supplied`) VALUES
(1, 'Maxicap', 'Capsule', 'Multivitamins + Lysine', 'TGP', 'TGP', 69, 4, 'Available', '2016-12-10'),
(2, 'Biogesic', 'Tablet', 'Analgesic 500mg', 'Nelpa', 'Nelpa', 0, 2, 'Available', '2016-12-10'),
(3, 'Extra', 'Tablet', 'Paracetamol', 'Panadol', 'Panadol', 100, 9, 'Available', '2016-12-10'),
(4, 'Multivitamins + Iron', 'Capsule', 'Multivitamins + Iron', 'Scheele', 'Scheele', 100, 5, 'Available', '2016-12-10'),
(5, 'Mefenamic Acid', 'Capsule', 'Analgesic Non-Steroidal', 'PhilRX', 'PhilRX', 75, 6, 'Available', '2016-12-10'),
(6, 'MultiVita', 'Capsule', 'Food Supplement', 'St. Barachiel', 'St. Barachiel', 97, 9, 'Available', '2016-12-10'),
(8, 'Abbocath 24', 'Syringe', '24G x 1', 'Introcan Safety', 'BBraun', 95, 18, 'Available', '2016-12-13'),
(9, 'Abbocath 26', 'Syringe', '26G x 1', 'Cathula', 'Hindustan Syringes &', 100, 21, 'Available', '2016-12-13'),
(10, '0.9% Sodium Chloride', 'Solution for Infusio', '500ml/0.9%', 'Euro-Med Laboratorie', 'Euro-Med Laboratorie', 85, 79, 'Available', '2016-12-13'),
(11, '5% Dextrose In Water', 'Dextrose', '5%/1000ml', 'Euro-Med Laboratorie', 'Euro-Med Laboratorie', 94, 99, 'Available', '2016-12-13'),
(12, 'AminoVit', 'Vitamin Solution', 'Amino Acids + Vitamin Solution', 'Largen Med Inc.', 'Taiwan Biotech.co', 90, 65, 'Available', '2016-12-13'),
(13, 'Face Mask', 'Surgical Mask', 'Surgical Mask', 'none', 'none', 92, 3, 'Available', '2016-12-13'),
(14, 'Surgical Gloves', 'Surgical Mask', 'Disposable Gloves/Medium', 'none', 'none', 92, 6, 'Available', '2016-12-13'),
(15, 'sample', 'sample', 'sample', 'sample', 'sample', 95, 5, 'Available', '2016-12-14');

-- --------------------------------------------------------

--
-- Table structure for table `tempprescri`
--

CREATE TABLE `tempprescri` (
  `id` tinyint(5) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(30) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `sex` varchar(6) DEFAULT NULL,
  `postal_address` varchar(30) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `drug_name` varchar(30) NOT NULL,
  `strength` varchar(30) NOT NULL,
  `dose` varchar(30) NOT NULL,
  `quantity` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cashier`
--
ALTER TABLE `cashier`
  ADD PRIMARY KEY (`cashier_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Indexes for table `invoice_details`
--
ALTER TABLE `invoice_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stocks` (`drug`),
  ADD KEY `invoices` (`invoice`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`manager_id`);

--
-- Indexes for table `paymenttypes`
--
ALTER TABLE `paymenttypes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pharmacist`
--
ALTER TABLE `pharmacist`
  ADD PRIMARY KEY (`pharmacist_id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`id`,`prescription_id`);

--
-- Indexes for table `prescription_details`
--
ALTER TABLE `prescription_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dsfd` (`drug_name`);

--
-- Indexes for table `receipts`
--
ALTER TABLE `receipts`
  ADD PRIMARY KEY (`reciptNo`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `tempprescri`
--
ALTER TABLE `tempprescri`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` tinyint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `cashier`
--
ALTER TABLE `cashier`
  MODIFY `cashier_id` tinyint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `invoice_details`
--
ALTER TABLE `invoice_details`
  MODIFY `id` tinyint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;
--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `manager_id` tinyint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `paymenttypes`
--
ALTER TABLE `paymenttypes`
  MODIFY `id` tinyint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pharmacist`
--
ALTER TABLE `pharmacist`
  MODIFY `pharmacist_id` tinyint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `id` tinyint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `prescription_details`
--
ALTER TABLE `prescription_details`
  MODIFY `id` tinyint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;
--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `stock_id` tinyint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tempprescri`
--
ALTER TABLE `tempprescri`
  MODIFY `id` tinyint(5) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice_details`
--
ALTER TABLE `invoice_details`
  ADD CONSTRAINT `invoices` FOREIGN KEY (`invoice`) REFERENCES `invoice` (`invoice_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `stocks` FOREIGN KEY (`drug`) REFERENCES `stock` (`stock_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prescription_details`
--
ALTER TABLE `prescription_details`
  ADD CONSTRAINT `dsfd` FOREIGN KEY (`drug_name`) REFERENCES `stock` (`stock_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
