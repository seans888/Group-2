<?php

if(isset($_POST["submit"])){
// checks if all field are answered 
if(!empty($_POST['uname']) && !empty($_POST['upass'])) {
	$user=$_POST['uname'];
	$pass=$_POST['upass'];

	$con=mysql_connect('localhost','root','') or die(mysql_error());
	mysql_select_db('cpr') or die("cannot select DB");

	$query=mysql_query("SELECT * FROM user WHERE uname='".$user."' AND upass='".$pass."'");
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
	while($row=mysql_fetch_assoc($query))
	{
	$dbuserpass=$row['upass'];
	$dbusername=$row['uname'];
	}

	if($dbuserpass == $pass && $dbusername == $user)
	{
	session_start();
	$_SESSION['uname']=$user;

	/* Redirect browser */
	header("Location: index.php");
	}
	/* elseif ($dbusertype == 'regular'&& $dbusername == $user) 
	{
	session_start();
	$_SESSION['user_name']=$user;
	header("Location: profile2.php"); // after validating redirect to the main profile of the user
	}*/
	

} else {
	echo "<script type='text/javascript'>alert('Email or password is incorrect!!')</script>";
}
}
}
?>