	<?php
   define('DB_NAME', 'cpr');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if(!$link) {
	die('Could not connect: ' . mysql_error());
	}
	
$db_selected = mysql_select_db(DB_NAME, $link);

if (!$db_selected) {
	die('Can\'t use ' . DB_NAME . ': ' . mysql_error());
	}
	
	$code=$_GET['mcode'];
	$name=$_GET['name'];
	$desc=$_GET['desc'];
	$price=$_GET['price'];
	$exp=$_GET['exp'];
	$ship=$_GET['ship'];
	$qty=$_GET['qty'];
	
	$sql7="INSERT INTO medicine VALUES
('$qty','$code', '$name', '$desc', '$price', '$exp', '$ship')";
	
	if (!mysql_query($sql7)) {
	die ('ERROR: ' . mysql_error());
	}

mysql_close();

echo "<script type='text/javascript'>alert('Insert Successful!')
	window.location.href='inventory.php';
	</script>";

?>
