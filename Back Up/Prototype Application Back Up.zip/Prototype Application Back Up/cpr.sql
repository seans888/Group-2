-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2016 at 09:42 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cpr`
--

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE IF NOT EXISTS `bills` (
  `OR_code` char(10) NOT NULL,
  `med_code` char(10) DEFAULT NULL,
  `quantity` double DEFAULT NULL,
  `pat_id` int(11) DEFAULT NULL,
  `bp_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`OR_code`, `med_code`, `quantity`, `pat_id`, `bp_date`) VALUES
('HHT68', 'BR411', 8, 0, '2016-08-20');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `dept_code` char(5) NOT NULL,
  `dept_name` varchar(45) DEFAULT NULL,
  `dept_desc` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_code`, `dept_name`, `dept_desc`) VALUES
('ICU', 'Intensive Care Unit', 'something'),
('SRD', 'Surgery Department', 'Sugeons etc. ');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE IF NOT EXISTS `doctors` (
`doc_id` int(11) NOT NULL,
  `doc_fname` varchar(45) DEFAULT NULL,
  `doc_lname` varchar(45) DEFAULT NULL,
  `doc_cont` double DEFAULT NULL,
  `doc_field` varchar(45) DEFAULT NULL,
  `dept_code` char(5) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`doc_id`, `doc_fname`, `doc_lname`, `doc_cont`, `doc_field`, `dept_code`) VALUES
(1, 'Juan', 'Dela Cruz', 9276234802, 'Surgeon', 'SRD'),
(2, 'Jihoon', 'Lee', 123456, 'Doctor', 'ICU');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE IF NOT EXISTS `medicine` (
  `med_qty` double NOT NULL,
  `med_code` char(10) NOT NULL,
  `med_name` varchar(45) DEFAULT NULL,
  `med_desc` varchar(45) DEFAULT NULL,
  `med_price` double DEFAULT NULL,
  `med_exp` date NOT NULL,
  `med_ship` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`med_qty`, `med_code`, `med_name`, `med_desc`, `med_price`, `med_exp`, `med_ship`) VALUES
(3, 'BR211', 'Bioflu', 'something', 5, '2016-08-31', '2016-08-01'),
(5, 'BR321', 'Biogesic', 'Something', 3, '2016-08-31', '2016-08-01'),
(10, 'BR411', 'Solmux', 'Cough Tablet', 6, '2016-12-31', '2016-08-01');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `pat_id` int(11) NOT NULL,
  `pat_fname` varchar(45) DEFAULT NULL,
  `pat_lname` varchar(45) DEFAULT NULL,
  `pat_addr` varchar(45) DEFAULT NULL,
  `pat_cont` varchar(15) DEFAULT NULL,
  `pat_class` varchar(45) NOT NULL,
  `pat_bday` date NOT NULL,
  `doc_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pat_id`, `pat_fname`, `pat_lname`, `pat_addr`, `pat_cont`, `pat_class`, `pat_bday`, `doc_id`) VALUES
(0, 'Juan', 'Dela Cruz', '99999999', 'manila', 'IN-patient', '2010-01-10', 1),
(1, 'Maria', 'Clara', 'Pasay City', '8548128', 'IN-Patient', '2016-08-03', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`user_id` int(11) NOT NULL,
  `fname` varchar(45) DEFAULT NULL,
  `lname` varchar(45) DEFAULT NULL,
  `cont` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `uname` varchar(45) DEFAULT NULL,
  `upass` varchar(45) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `fname`, `lname`, `cont`, `position`, `uname`, `upass`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
 ADD PRIMARY KEY (`OR_code`), ADD KEY `med_code` (`med_code`), ADD KEY `pat_id` (`pat_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
 ADD PRIMARY KEY (`dept_code`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
 ADD PRIMARY KEY (`doc_id`), ADD KEY `dept_code` (`dept_code`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
 ADD PRIMARY KEY (`med_code`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
 ADD PRIMARY KEY (`pat_id`), ADD KEY `doc_id` (`doc_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
MODIFY `doc_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `bills`
--
ALTER TABLE `bills`
ADD CONSTRAINT `bills_ibfk_1` FOREIGN KEY (`med_code`) REFERENCES `medicine` (`med_code`),
ADD CONSTRAINT `bills_ibfk_2` FOREIGN KEY (`pat_id`) REFERENCES `patient` (`pat_id`);

--
-- Constraints for table `doctors`
--
ALTER TABLE `doctors`
ADD CONSTRAINT `doctors_ibfk_1` FOREIGN KEY (`dept_code`) REFERENCES `department` (`dept_code`);

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
ADD CONSTRAINT `patient_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `doctors` (`doc_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
